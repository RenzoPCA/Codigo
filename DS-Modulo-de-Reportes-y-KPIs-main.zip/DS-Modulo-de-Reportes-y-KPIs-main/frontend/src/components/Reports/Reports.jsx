/**
 * Reports Component - Display tabular reports
 */
import './Reports.css';

function Reports() {
  return (
    <div className="reports">
      <h1>Reportes</h1>
      <p>Componente de reportes - Por implementar</p>
    </div>
  );
}

export default Reports;
